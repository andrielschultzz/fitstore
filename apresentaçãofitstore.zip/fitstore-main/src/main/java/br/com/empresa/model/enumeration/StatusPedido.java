package br.com.empresa.model.enumeration;

public enum StatusPedido {
    ABERTO, CONFIRMADO, PAGO, CANCELADO, ENTREGUE
}
