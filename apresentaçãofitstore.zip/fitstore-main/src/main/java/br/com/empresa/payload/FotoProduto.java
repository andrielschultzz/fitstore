package br.com.empresa.payload;

public class FotoProduto {
    public String uuid;
}